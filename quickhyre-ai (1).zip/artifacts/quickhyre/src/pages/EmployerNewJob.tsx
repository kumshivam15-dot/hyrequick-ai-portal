import { useLocation, Link } from "wouter";
import { useCreateJob, useListCompanies, getListJobsQueryKey } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const formSchema = z.object({
  title: z.string().min(3, "Title is required"),
  companyId: z.coerce.number().min(1, "Company is required"),
  location: z.string().min(2, "Location is required"),
  type: z.enum(["full-time", "part-time", "contract", "internship", "remote"]),
  category: z.string().min(2, "Category is required"),
  description: z.string().min(20, "Description is too short"),
  requirements: z.string().min(20, "Requirements are too short"),
  salaryMin: z.coerce.number().optional().or(z.literal(0)),
  salaryMax: z.coerce.number().optional().or(z.literal(0)),
  tags: z.string().optional()
});

type FormValues = z.infer<typeof formSchema>;

export default function EmployerNewJob() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: companies } = useListCompanies({ query: { queryKey: ["companies"] } });
  
  const createMutation = useCreateJob();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      location: "",
      type: "full-time",
      category: "",
      description: "",
      requirements: "",
      tags: ""
    }
  });

  const onSubmit = (values: FormValues) => {
    const tagsArray = values.tags ? values.tags.split(",").map(t => t.trim()).filter(Boolean) : [];
    
    createMutation.mutate({
      data: {
        title: values.title,
        companyId: values.companyId,
        location: values.location,
        type: values.type,
        category: values.category,
        description: values.description,
        requirements: values.requirements,
        salaryMin: values.salaryMin || null,
        salaryMax: values.salaryMax || null,
        tags: tagsArray
      }
    }, {
      onSuccess: () => {
        toast({ title: "Job posted successfully!" });
        queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
        setLocation("/employer/jobs");
      },
      onError: (err: any) => {
        toast({ title: "Error posting job", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <div className="container max-w-screen-md mx-auto px-4 py-8 mb-20">
      <Link href="/employer/jobs" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-2 mb-6 font-mono">
        <ArrowLeft className="w-4 h-4" /> Back to jobs
      </Link>
      
      <div className="mb-8 border-b border-border/50 pb-4">
        <h1 className="text-3xl font-bold tracking-tight">Post a New Job</h1>
        <p className="text-muted-foreground mt-1">Create a new listing to attract top talent.</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 bg-card border border-border/50 p-6 md:p-8 rounded-xl shadow-sm">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField control={form.control} name="title" render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel className="font-mono">Job Title *</FormLabel>
                <FormControl><Input placeholder="e.g. Senior Frontend Engineer" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="companyId" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Company *</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {companies?.map(c => (
                      <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="type" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Employment Type *</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="full-time">Full-time</SelectItem>
                    <SelectItem value="part-time">Part-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="internship">Internship</SelectItem>
                    <SelectItem value="remote">Remote</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="location" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Location *</FormLabel>
                <FormControl><Input placeholder="e.g. San Francisco, CA or Remote" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="category" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Category *</FormLabel>
                <FormControl><Input placeholder="e.g. Engineering" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-border/50">
            <FormField control={form.control} name="salaryMin" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Min Salary (USD)</FormLabel>
                <FormControl><Input type="number" placeholder="e.g. 100000" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="salaryMax" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Max Salary (USD)</FormLabel>
                <FormControl><Input type="number" placeholder="e.g. 150000" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <div className="space-y-6 pt-4 border-t border-border/50">
            <FormField control={form.control} name="description" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Job Description *</FormLabel>
                <FormControl><Textarea placeholder="Describe the role and responsibilities..." className="h-32" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="requirements" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Requirements *</FormLabel>
                <FormControl><Textarea placeholder="What qualifications are needed?" className="h-32" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="tags" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Tags (comma separated)</FormLabel>
                <FormControl><Input placeholder="React, TypeScript, Node.js" {...field} /></FormControl>
                <FormDescription>Keywords to help candidates find this job.</FormDescription>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <div className="pt-6">
            <Button type="submit" size="lg" className="w-full text-base" disabled={createMutation.isPending}>
              {createMutation.isPending && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              Publish Job Listing
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

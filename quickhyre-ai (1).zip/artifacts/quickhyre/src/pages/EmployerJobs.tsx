import { useState } from "react";
import { Link } from "wouter";
import { useListJobs, useDeleteJob, getListJobsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Users, Edit, Trash2, ExternalLink } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function EmployerJobs() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // We list all jobs, but in a real app this would filter by the current employer's companyId
  const { data: jobs, isLoading } = useListJobs({}, { query: { queryKey: ["employer-jobs"] } });
  
  const deleteMutation = useDeleteJob({
    mutation: {
      onSuccess: () => {
        toast({ title: "Job deleted" });
        queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
        queryClient.invalidateQueries({ queryKey: ["employer-jobs"] });
      }
    }
  });

  return (
    <div className="container max-w-screen-xl mx-auto px-4 md:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between border-b border-border/50 pb-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Job Listings</h1>
          <p className="text-muted-foreground mt-1">Manage your active roles and track applicants.</p>
        </div>
        <Button asChild>
          <Link href="/employer/jobs/new">
            <Plus className="w-4 h-4 mr-2" /> Post New Job
          </Link>
        </Button>
      </div>

      <div className="border border-border/50 rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader className="bg-secondary/30">
            <TableRow>
              <TableHead className="font-mono text-xs uppercase tracking-wider">Role</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider">Status</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-center">Applicants</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider">Posted</TableHead>
              <TableHead className="font-mono text-xs uppercase tracking-wider text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={5} className="text-center p-8 animate-pulse font-mono">Loading...</TableCell></TableRow>
            ) : jobs?.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center p-8 text-muted-foreground font-mono">No jobs posted yet.</TableCell></TableRow>
            ) : (
              jobs?.map(job => (
                <TableRow key={job.id}>
                  <TableCell>
                    <div className="font-bold">{job.title}</div>
                    <div className="text-xs text-muted-foreground font-mono mt-1">{job.location} &bull; {job.type}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={job.isActive ? "default" : "secondary"} className="font-mono text-[10px]">
                      {job.isActive ? "ACTIVE" : "CLOSED"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    <Button variant="ghost" asChild className="gap-2 font-mono" size="sm">
                      <Link href={`/employer/jobs/${job.id}/applicants`}>
                        <Users className="w-4 h-4" /> {job.applicationCount}
                      </Link>
                    </Button>
                  </TableCell>
                  <TableCell className="font-mono text-sm text-muted-foreground">
                    {new Date(job.postedAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild title="View Public Posting">
                        <Link href={`/jobs/${job.id}`}><ExternalLink className="w-4 h-4 text-muted-foreground" /></Link>
                      </Button>
                      <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() => {
                          if (confirm("Delete this job posting?")) {
                            deleteMutation.mutate({ id: job.id });
                          }
                        }}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

import { Link, useLocation } from "wouter";
import { useGetPlatformStats, useListJobs, useListCompanies } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, TrendingUp, Building, Users, Briefcase, ArrowRight } from "lucide-react";
import { JobCard, CompanyCard } from "@/components/shared";
import { useState } from "react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");

  const { data: stats } = useGetPlatformStats();
  const { data: jobs } = useListJobs({ }, { query: { queryKey: ["home-jobs"] } });
  const { data: companies } = useListCompanies({ query: { queryKey: ["home-companies"] } });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      setLocation(`/jobs?search=${encodeURIComponent(search)}`);
    } else {
      setLocation("/jobs");
    }
  };

  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="bg-card border-b border-border py-24 px-4 md:px-8">
        <div className="container max-w-screen-xl mx-auto flex flex-col items-center text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-mono tracking-tight border border-primary/20">
            <TrendingUp className="w-4 h-4" />
            <span>Over {stats?.totalHires.toLocaleString() ?? "1,000"}+ hires made this month</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-foreground max-w-4xl">
            Command Center for <span className="text-primary">Top Talent</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            High-density, precise, and built for scale. QuickHyre AI connects serious professionals with the world's most ambitious companies.
          </p>
          
          <form onSubmit={handleSearch} className="flex w-full max-w-2xl gap-2 mt-4 relative">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input 
                placeholder="Search jobs, skills, or companies..." 
                className="pl-10 h-14 text-lg bg-background border-border/60 shadow-sm"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Button type="submit" size="lg" className="h-14 px-8 text-base">Search</Button>
          </form>

          <div className="flex flex-wrap justify-center gap-8 pt-8 mt-4 border-t border-border/40 w-full max-w-4xl">
            <StatItem icon={<Briefcase />} value={stats?.totalJobs.toLocaleString() ?? "0"} label="Open Positions" />
            <StatItem icon={<Building />} value={stats?.totalCompanies.toLocaleString() ?? "0"} label="Companies" />
            <StatItem icon={<Users />} value={stats?.totalApplications.toLocaleString() ?? "0"} label="Active Applications" />
          </div>
        </div>
      </section>

      {/* Featured Jobs */}
      <section className="py-20 px-4 md:px-8 bg-background">
        <div className="container max-w-screen-xl mx-auto space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Recent Opportunities</h2>
              <p className="text-muted-foreground mt-2">Latest roles from top-tier organizations.</p>
            </div>
            <Button variant="outline" onClick={() => setLocation("/jobs")} className="hidden sm:flex font-mono">
              View All <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {jobs?.slice(0, 5).map(job => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
          <Button variant="outline" onClick={() => setLocation("/jobs")} className="w-full sm:hidden font-mono mt-4">
            View All Jobs
          </Button>
        </div>
      </section>

      {/* Featured Companies */}
      <section className="py-20 px-4 md:px-8 bg-secondary/30 border-t border-border/40">
        <div className="container max-w-screen-xl mx-auto space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Featured Companies</h2>
              <p className="text-muted-foreground mt-2">Organizations actively hiring on QuickHyre AI.</p>
            </div>
            <Button variant="outline" onClick={() => setLocation("/companies")} className="hidden sm:flex font-mono">
              Directory <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {companies?.slice(0, 6).map(company => (
              <CompanyCard key={company.id} company={company} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function StatItem({ icon, value, label }: { icon: React.ReactNode, value: string, label: string }) {
  return (
    <div className="flex items-center gap-4 text-left">
      <div className="p-3 rounded-md bg-secondary text-secondary-foreground border border-border/50">
        {icon}
      </div>
      <div>
        <div className="text-2xl font-bold font-mono tracking-tight">{value}</div>
        <div className="text-sm text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

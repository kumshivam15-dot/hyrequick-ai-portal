import { useGetEmployerStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { Users, Briefcase, FileText, CheckCircle, TrendingUp, ChevronRight } from "lucide-react";
import { StatusBadge } from "@/components/shared";

export default function EmployerDashboard() {
  const { data: stats, isLoading } = useGetEmployerStats();

  if (isLoading) return <div className="p-8 font-mono animate-pulse">Loading dashboard...</div>;
  if (!stats) return null;

  return (
    <div className="container max-w-screen-xl mx-auto px-4 md:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between border-b border-border/50 pb-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Employer Overview</h1>
          <p className="text-muted-foreground mt-1">Real-time insights across your hiring pipeline.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Active Jobs" value={stats.activeJobs} icon={<Briefcase />} />
        <StatCard title="Total Applications" value={stats.totalApplications} icon={<FileText />} />
        <StatCard title="Pending Review" value={stats.pendingReview} icon={<Users />} />
        <StatCard title="Hired" value={stats.hired} icon={<CheckCircle />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2 border-b border-border/50">
              <CardTitle className="text-xl">Recent Applications</CardTitle>
              <Link href="/employer/jobs" className="text-sm font-mono text-primary hover:underline flex items-center">
                View All <ChevronRight className="w-4 h-4" />
              </Link>
            </CardHeader>
            <CardContent className="p-0">
              {stats.recentApplications?.length > 0 ? (
                <div className="divide-y divide-border/50">
                  {stats.recentApplications.map(app => (
                    <div key={app.id} className="p-4 flex items-center justify-between hover:bg-secondary/20 transition-colors">
                      <div>
                        <div className="font-bold">{app.candidateName}</div>
                        <div className="text-sm text-muted-foreground font-mono mt-1">Applied for <span className="text-foreground">{app.jobTitle}</span></div>
                      </div>
                      <div className="text-right">
                        <StatusBadge status={app.status} />
                        <div className="text-xs text-muted-foreground mt-2">{new Date(app.appliedAt).toLocaleDateString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-muted-foreground font-mono">No recent applications.</div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-border/50 shadow-sm">
            <CardHeader className="border-b border-border/50">
              <CardTitle className="text-xl">Pipeline Health</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              {stats.applicationsByStatus?.map(stat => (
                <div key={stat.status} className="flex items-center justify-between">
                  <span className="capitalize font-mono text-sm">{stat.status}</span>
                  <span className="font-bold">{stat.count}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/20 shadow-sm">
            <CardContent className="p-6 flex items-start gap-4">
              <div className="p-3 bg-primary/20 rounded-md text-primary">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold mb-1">Current Headcount</h3>
                <div className="text-3xl font-mono tracking-tight font-bold">{stats.headcount}</div>
                <Link href="/employer/hrms" className="text-sm text-primary hover:underline mt-2 inline-block">Manage Directory →</Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string, value: number, icon: React.ReactNode }) {
  return (
    <Card className="border-border/50 shadow-sm">
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <h3 className="text-3xl font-bold tracking-tight font-mono">{value}</h3>
        </div>
        <div className="p-3 bg-secondary/50 rounded-md text-muted-foreground border border-border/50">
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}

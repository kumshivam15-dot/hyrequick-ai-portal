import { useRoute, Link } from "wouter";
import { 
  useGetJob, 
  useListJobApplications, 
  useUpdateApplication,
  ApplicationStatus,
  getListJobApplicationsQueryKey
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Mail, Phone, ExternalLink, MoreHorizontal, Check, X } from "lucide-react";
import { StatusBadge } from "@/components/shared";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function EmployerATS() {
  const [, params] = useRoute("/employer/jobs/:id/applicants");
  const jobId = parseInt(params?.id || "0", 10);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: job, isLoading: jobLoading } = useGetJob(jobId, {
    query: { enabled: !!jobId, queryKey: ["job", jobId] }
  });

  const { data: applications, isLoading: appsLoading } = useListJobApplications(jobId, {
    query: { enabled: !!jobId, queryKey: ["job-applications", jobId] }
  });

  const updateMutation = useUpdateApplication({
    mutation: {
      onSuccess: () => {
        toast({ title: "Status updated" });
        queryClient.invalidateQueries({ queryKey: getListJobApplicationsQueryKey(jobId) });
        queryClient.invalidateQueries({ queryKey: ["job-applications", jobId] });
      }
    }
  });

  if (jobLoading) return <div className="p-8 font-mono animate-pulse">Loading ATS...</div>;
  if (!job) return <div className="p-8 font-mono">Job not found.</div>;

  return (
    <div className="container max-w-screen-2xl mx-auto px-4 md:px-8 py-8 h-[calc(100vh-140px)] flex flex-col">
      <Link href="/employer/jobs" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-2 mb-6 font-mono shrink-0">
        <ArrowLeft className="w-4 h-4" /> Back to job management
      </Link>

      <div className="flex items-center justify-between border-b border-border/50 pb-4 mb-6 shrink-0">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{job.title}</h1>
          <p className="text-muted-foreground mt-1 font-mono text-sm">
            Applicant Tracking System &bull; {job.location} &bull; {applications?.length || 0} candidates
          </p>
        </div>
        <Button variant="outline" asChild>
          <Link href={`/jobs/${job.id}`}><ExternalLink className="w-4 h-4 mr-2" /> View Listing</Link>
        </Button>
      </div>

      <div className="flex-1 overflow-x-auto overflow-y-hidden pb-4">
        {appsLoading ? (
          <div className="flex gap-4 h-full animate-pulse">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="w-80 h-full bg-secondary/20 border border-border/50 rounded-xl shrink-0" />
            ))}
          </div>
        ) : (
          <div className="flex gap-6 h-full items-start">
            {Object.values(ApplicationStatus).map(status => {
              const statusApps = applications?.filter(app => app.status === status) || [];
              if (statusApps.length === 0 && (status === "rejected" || status === "hired")) return null;
              
              return (
                <div key={status} className="w-80 bg-secondary/10 border border-border/50 rounded-xl flex flex-col max-h-full shrink-0">
                  <div className="p-4 border-b border-border/50 bg-card rounded-t-xl shrink-0 flex items-center justify-between">
                    <h3 className="font-bold tracking-tight capitalize">{status}</h3>
                    <div className="w-6 h-6 rounded-full bg-secondary text-secondary-foreground text-xs font-bold font-mono flex items-center justify-center">
                      {statusApps.length}
                    </div>
                  </div>
                  
                  <div className="p-3 flex-1 overflow-y-auto space-y-3">
                    {statusApps.map(app => (
                      <div key={app.id} className="bg-card border border-border/50 rounded-lg p-4 shadow-sm hover:border-primary/50 transition-colors">
                        <div className="flex items-start justify-between mb-2">
                          <div className="font-bold tracking-tight">{app.candidateName}</div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 -mr-2 -mt-2"><MoreHorizontal className="w-4 h-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Change Status</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              {Object.values(ApplicationStatus).map(s => (
                                <DropdownMenuItem 
                                  key={s} 
                                  disabled={s === app.status}
                                  onClick={() => updateMutation.mutate({ id: app.id, data: { status: s } })}
                                >
                                  Mark as {s}
                                </DropdownMenuItem>
                              ))}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        
                        <div className="space-y-1.5 mb-3 text-sm text-muted-foreground font-mono">
                          <div className="flex items-center gap-2"><Mail className="w-3.5 h-3.5" /> <span className="truncate">{app.candidateEmail}</span></div>
                          {app.candidatePhone && <div className="flex items-center gap-2"><Phone className="w-3.5 h-3.5" /> <span>{app.candidatePhone}</span></div>}
                        </div>
                        
                        {app.resumeUrl && (
                          <div className="mt-3 pt-3 border-t border-border/50">
                            <Button variant="outline" size="sm" className="w-full text-xs font-mono" asChild>
                              <a href={app.resumeUrl} target="_blank" rel="noreferrer">
                                <ExternalLink className="w-3 h-3 mr-2" /> View Resume
                              </a>
                            </Button>
                          </div>
                        )}
                        
                        {(app.status === "pending" || app.status === "reviewed") && (
                          <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-border/50">
                            <Button size="sm" variant="outline" className="text-xs bg-red-500/10 text-red-600 border-red-500/20 hover:bg-red-500/20 hover:text-red-700"
                              onClick={() => updateMutation.mutate({ id: app.id, data: { status: "rejected" } })}>
                              <X className="w-3 h-3 mr-1" /> Reject
                            </Button>
                            <Button size="sm" variant="outline" className="text-xs bg-green-500/10 text-green-600 border-green-500/20 hover:bg-green-500/20 hover:text-green-700"
                              onClick={() => updateMutation.mutate({ id: app.id, data: { status: "shortlisted" } })}>
                              <Check className="w-3 h-3 mr-1" /> Advance
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                    {statusApps.length === 0 && (
                      <div className="p-4 text-center text-sm font-mono text-muted-foreground border-2 border-dashed border-border/50 rounded-lg">
                        Empty
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

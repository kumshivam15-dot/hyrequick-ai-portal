import { useListCompanies } from "@workspace/api-client-react";
import { CompanyCard } from "@/components/shared";
import { Building2 } from "lucide-react";

export default function Companies() {
  const { data: companies, isLoading } = useListCompanies({ query: { queryKey: ["companies"] } });

  return (
    <div className="container max-w-screen-xl mx-auto px-4 md:px-8 py-12">
      <div className="flex flex-col gap-2 mb-10 border-b border-border/50 pb-8">
        <h1 className="text-4xl font-bold tracking-tight flex items-center gap-3">
          <Building2 className="w-10 h-10 text-primary" />
          Company Directory
        </h1>
        <p className="text-xl text-muted-foreground">Explore top organizations hiring on QuickHyre AI.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-64 bg-card border border-border/50 rounded-lg animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {companies?.map(company => (
            <CompanyCard key={company.id} company={company} />
          ))}
        </div>
      )}
    </div>
  );
}

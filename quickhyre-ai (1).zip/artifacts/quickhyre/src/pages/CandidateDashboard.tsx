import { useGetCandidateStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { FileText, Clock, CheckCircle, XCircle, Search, ExternalLink } from "lucide-react";
import { StatusBadge } from "@/components/shared";
import { Button } from "@/components/ui/button";

export default function CandidateDashboard() {
  const { data: stats, isLoading } = useGetCandidateStats();

  if (isLoading) return <div className="p-8 font-mono animate-pulse">Loading dashboard...</div>;
  if (!stats) return null;

  return (
    <div className="container max-w-screen-xl mx-auto px-4 md:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between border-b border-border/50 pb-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Candidate Portal</h1>
          <p className="text-muted-foreground mt-1">Track your applications and next steps.</p>
        </div>
        <Button asChild>
          <Link href="/jobs"><Search className="w-4 h-4 mr-2" /> Find Jobs</Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatCard title="Applied" value={stats.totalApplied} icon={<FileText />} />
        <StatCard title="In Review" value={stats.underReview} icon={<Clock />} />
        <StatCard title="Interviews" value={stats.interviews} icon={<CheckCircle className="text-primary" />} />
        <StatCard title="Offers" value={stats.offers} icon={<CheckCircle className="text-green-500" />} />
        <StatCard title="Rejected" value={stats.rejected} icon={<XCircle className="text-destructive" />} />
      </div>

      <div className="space-y-6">
        <h2 className="text-2xl font-bold tracking-tight">My Applications</h2>
        
        {stats.recentApplications?.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stats.recentApplications.map(app => (
              <Card key={app.id} className="border-border/50 hover:border-primary/50 transition-colors flex flex-col shadow-sm hover-elevate">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg leading-tight mb-1">{app.jobTitle}</CardTitle>
                      <div className="text-sm font-mono text-muted-foreground">{app.companyName}</div>
                    </div>
                    <StatusBadge status={app.status} />
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-end">
                  <div className="text-xs text-muted-foreground font-mono mb-4 pt-4 border-t border-border/50">
                    Applied {new Date(app.appliedAt).toLocaleDateString()}
                  </div>
                  <Button variant="outline" className="w-full font-mono" asChild>
                    <Link href={`/jobs/${app.jobId}`}>
                      <ExternalLink className="w-4 h-4 mr-2" /> View Listing
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-card border border-border/50 rounded-xl">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-bold">No applications yet</h3>
            <p className="text-muted-foreground mt-1 mb-6">Start applying to jobs to track your progress here.</p>
            <Button asChild><Link href="/jobs">Browse Jobs</Link></Button>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string, value: number, icon: React.ReactNode }) {
  return (
    <Card className="border-border/50 shadow-sm">
      <CardContent className="p-4 flex flex-col justify-between h-full gap-4">
        <div className="flex items-center justify-between">
          <p className="text-xs font-mono font-medium text-muted-foreground uppercase">{title}</p>
          <div className="text-muted-foreground opacity-50">{icon}</div>
        </div>
        <h3 className="text-3xl font-bold tracking-tight font-mono">{value}</h3>
      </CardContent>
    </Card>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { useListJobs } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, SlidersHorizontal } from "lucide-react";
import { JobCard } from "@/components/shared";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ListJobsType } from "@workspace/api-client-react";

export default function Jobs() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const initialSearch = searchParams.get("search") || "";
  
  const [search, setSearch] = useState(initialSearch);
  const [type, setType] = useState<ListJobsType | "">("");
  const [query, setQuery] = useState(initialSearch);

  const { data: jobs, isLoading } = useListJobs(
    { search: query, type: type as ListJobsType || undefined },
    { query: { queryKey: ["jobs", query, type] } }
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setQuery(search);
  };

  return (
    <div className="container max-w-screen-xl mx-auto px-4 md:px-8 py-8 flex flex-col md:flex-row gap-8">
      {/* Sidebar Filters */}
      <aside className="w-full md:w-64 shrink-0 space-y-6">
        <div>
          <h2 className="text-lg font-bold tracking-tight mb-4 flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5" /> Filters
          </h2>
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground font-mono">Keywords</label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input 
                  placeholder="Job title..." 
                  className="pl-9 font-mono text-sm"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground font-mono">Job Type</label>
              <Select value={type} onValueChange={(val: any) => setType(val === "all" ? "" : val)}>
                <SelectTrigger className="font-mono text-sm">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  <SelectItem value="full-time">Full-time</SelectItem>
                  <SelectItem value="part-time">Part-time</SelectItem>
                  <SelectItem value="contract">Contract</SelectItem>
                  <SelectItem value="internship">Internship</SelectItem>
                  <SelectItem value="remote">Remote</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button type="submit" className="w-full font-mono">Apply Filters</Button>
          </form>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 space-y-4">
        <div className="flex items-center justify-between pb-4 border-b border-border/50">
          <h1 className="text-3xl font-bold tracking-tight">Browse Jobs</h1>
          <div className="text-sm text-muted-foreground font-mono">
            {jobs?.length || 0} results found
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-40 bg-card border border-border/50 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : jobs?.length === 0 ? (
          <div className="text-center py-20 bg-card border border-border/50 rounded-lg">
            <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-bold">No jobs found</h3>
            <p className="text-muted-foreground mt-1">Try adjusting your search or filters.</p>
            <Button variant="outline" className="mt-4" onClick={() => { setSearch(""); setType(""); setQuery(""); }}>
              Clear Filters
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {jobs?.map(job => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

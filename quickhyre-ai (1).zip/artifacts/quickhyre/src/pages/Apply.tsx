import { useRoute, useLocation, Link } from "wouter";
import { useGetJob, useApplyToJob } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Building, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  candidateName: z.string().min(2, "Name is required"),
  candidateEmail: z.string().email("Invalid email address"),
  candidatePhone: z.string().optional(),
  resumeUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  coverLetter: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function Apply() {
  const [, params] = useRoute("/apply/:jobId");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const jobId = parseInt(params?.jobId || "0", 10);

  const { data: job, isLoading: jobLoading } = useGetJob(jobId, { 
    query: { enabled: !!jobId, queryKey: ["job", jobId] } 
  });

  const applyMutation = useApplyToJob();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      candidateName: "",
      candidateEmail: "",
      candidatePhone: "",
      resumeUrl: "",
      coverLetter: "",
    },
  });

  const onSubmit = (values: FormValues) => {
    applyMutation.mutate({
      id: jobId,
      data: {
        candidateName: values.candidateName,
        candidateEmail: values.candidateEmail,
        candidatePhone: values.candidatePhone || undefined,
        resumeUrl: values.resumeUrl || undefined,
        coverLetter: values.coverLetter || undefined,
      }
    }, {
      onSuccess: () => {
        toast({ title: "Application submitted successfully!" });
        setLocation("/candidate");
      },
      onError: (err: any) => {
        toast({ title: "Error submitting application", description: err.message, variant: "destructive" });
      }
    });
  };

  if (jobLoading) return <div className="p-8 text-center font-mono">Loading...</div>;
  if (!job) return <div className="p-8 text-center font-mono">Job not found.</div>;

  return (
    <div className="container max-w-screen-md mx-auto px-4 py-8 mb-20">
      <Link href={`/jobs/${job.id}`} className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-2 mb-6 font-mono">
        <ArrowLeft className="w-4 h-4" /> Back to job
      </Link>
      
      <div className="mb-8 border-b border-border/50 pb-8">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Apply for {job.title}</h1>
        <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
          <Building className="w-4 h-4" /> {job.companyName} &mdash; {job.location}
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField control={form.control} name="candidateName" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Full Name *</FormLabel>
                <FormControl><Input placeholder="Jane Doe" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="candidateEmail" render={({ field }) => (
              <FormItem>
                <FormLabel className="font-mono">Email Address *</FormLabel>
                <FormControl><Input type="email" placeholder="jane@example.com" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>

          <FormField control={form.control} name="candidatePhone" render={({ field }) => (
            <FormItem>
              <FormLabel className="font-mono">Phone Number</FormLabel>
              <FormControl><Input type="tel" placeholder="+1 (555) 000-0000" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <FormField control={form.control} name="resumeUrl" render={({ field }) => (
            <FormItem>
              <FormLabel className="font-mono">Resume URL</FormLabel>
              <FormControl><Input placeholder="https://linkedin.com/in/..." {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <FormField control={form.control} name="coverLetter" render={({ field }) => (
            <FormItem>
              <FormLabel className="font-mono">Cover Letter / Notes</FormLabel>
              <FormControl><Textarea placeholder="Why are you a great fit?" className="h-32" {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />

          <Button type="submit" size="lg" className="w-full text-base" disabled={applyMutation.isPending}>
            {applyMutation.isPending && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
            Submit Application
          </Button>
        </form>
      </Form>
    </div>
  );
}

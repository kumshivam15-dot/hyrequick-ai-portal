import { useRoute, Link } from "wouter";
import { useGetJob } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Building, MapPin, DollarSign, Clock, CheckCircle2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function JobDetail() {
  const [, params] = useRoute("/jobs/:id");
  const jobId = parseInt(params?.id || "0", 10);

  const { data: job, isLoading, error } = useGetJob(jobId, { 
    query: { enabled: !!jobId, queryKey: ["job", jobId] } 
  });

  if (isLoading) {
    return (
      <div className="container max-w-screen-md mx-auto px-4 py-8 space-y-8">
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-16 w-3/4" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="container max-w-screen-md mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Job not found</h1>
        <p className="text-muted-foreground mt-2">This position may have been closed or removed.</p>
        <Button asChild className="mt-6">
          <Link href="/jobs">Back to Jobs</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-screen-md mx-auto px-4 py-8 mb-20">
      <div className="mb-8">
        <Link href="/jobs" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-2 mb-6 font-mono">
          <ArrowLeft className="w-4 h-4" /> Back to listings
        </Link>
        
        <div className="flex items-center gap-2 mb-4">
          <Badge variant={job.isActive ? "default" : "secondary"} className="font-mono">
            {job.isActive ? "ACTIVE" : "CLOSED"}
          </Badge>
          <Badge variant="outline" className="font-mono uppercase">{job.type}</Badge>
          <Badge variant="outline" className="font-mono uppercase">{job.category}</Badge>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">{job.title}</h1>
        
        <div className="flex flex-wrap items-center gap-y-4 gap-x-8 text-sm md:text-base text-muted-foreground border-b border-border/50 pb-8">
          <div className="flex items-center gap-2">
            <Building className="w-5 h-5 text-primary" />
            <Link href={`/companies/${job.companyId}`} className="hover:text-foreground font-medium transition-colors">
              {job.companyName}
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-primary" />
            {job.location}
          </div>
          {(job.salaryMin || job.salaryMax) && (
            <div className="flex items-center gap-2 font-mono">
              <DollarSign className="w-5 h-5 text-primary" />
              {job.salaryMin?.toLocaleString()} - {job.salaryMax?.toLocaleString()}
            </div>
          )}
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" />
            Posted {new Date(job.postedAt).toLocaleDateString()}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <section className="space-y-4">
            <h2 className="text-2xl font-bold tracking-tight">About the Role</h2>
            <div className="prose prose-sm md:prose-base dark:prose-invert max-w-none text-muted-foreground leading-relaxed whitespace-pre-line">
              {job.description}
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold tracking-tight">Requirements</h2>
            <div className="prose prose-sm md:prose-base dark:prose-invert max-w-none text-muted-foreground leading-relaxed whitespace-pre-line">
              {job.requirements}
            </div>
          </section>
        </div>

        <div className="md:col-span-1">
          <div className="bg-card border border-border/50 rounded-xl p-6 sticky top-24 space-y-6 shadow-sm">
            <h3 className="font-bold tracking-tight text-lg">Interested?</h3>
            <p className="text-sm text-muted-foreground">
              Join {job.companyName} and help build the future. 
              <br/><br/>
              <span className="font-mono text-xs text-primary">{job.applicationCount} applications so far</span>
            </p>
            <Button size="lg" className="w-full text-base" asChild disabled={!job.isActive}>
              <Link href={`/apply/${job.id}`}>
                {job.isActive ? "Apply Now" : "Position Closed"}
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

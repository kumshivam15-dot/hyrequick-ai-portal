import { useState } from "react";
import { 
  useListEmployees, 
  useCreateEmployee, 
  useUpdateEmployee, 
  useDeleteEmployee,
  useListCompanies,
  EmployeeStatus,
  EmployeeEmploymentType
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, UserMinus, MoreHorizontal, Mail, Phone, Calendar, Users, Building } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const formSchema = z.object({
  companyId: z.coerce.number().min(1, "Company is required"),
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email"),
  phone: z.string().optional(),
  role: z.string().min(2, "Role is required"),
  department: z.string().min(2, "Department is required"),
  employmentType: z.enum(["full-time", "part-time", "contract", "intern"]),
  startDate: z.string().min(1, "Start date is required"),
  salary: z.coerce.number().optional()
});

type FormValues = z.infer<typeof formSchema>;

export default function EmployerHRMS() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("");
  const [isAddOpen, setIsAddOpen] = useState(false);

  const { data: companies } = useListCompanies({ query: { queryKey: ["companies"] } });
  
  const { data: employees, isLoading } = useListEmployees(
    { department: department || undefined },
    { query: { queryKey: ["employees", department] } }
  );

  const createMutation = useCreateEmployee();
  const updateMutation = useUpdateEmployee();
  const deleteMutation = useDeleteEmployee();

  const filteredEmployees = employees?.filter(emp => 
    emp.name.toLowerCase().includes(search.toLowerCase()) || 
    emp.role.toLowerCase().includes(search.toLowerCase()) ||
    emp.email.toLowerCase().includes(search.toLowerCase())
  );

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      companyId: undefined,
      name: "",
      email: "",
      phone: "",
      role: "",
      department: "",
      employmentType: "full-time",
      startDate: new Date().toISOString().split('T')[0],
      salary: undefined
    }
  });

  const onSubmit = (values: FormValues) => {
    createMutation.mutate({
      data: {
        ...values,
        phone: values.phone || undefined,
        salary: values.salary || undefined
      }
    }, {
      onSuccess: () => {
        toast({ title: "Employee added successfully" });
        setIsAddOpen(false);
        form.reset();
        queryClient.invalidateQueries({ queryKey: ["employees"] });
      },
      onError: (err: any) => {
        toast({ title: "Error adding employee", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleUpdateStatus = (id: number, status: EmployeeStatus) => {
    updateMutation.mutate({ id, data: { status } }, {
      onSuccess: () => {
        toast({ title: "Status updated" });
        queryClient.invalidateQueries({ queryKey: ["employees"] });
      }
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to remove this employee? This action cannot be undone.")) {
      deleteMutation.mutate({ id }, {
        onSuccess: () => {
          toast({ title: "Employee removed" });
          queryClient.invalidateQueries({ queryKey: ["employees"] });
        }
      });
    }
  };

  const departments = Array.from(new Set(employees?.map(e => e.department) || []));

  return (
    <div className="container max-w-screen-xl mx-auto px-4 md:px-8 py-8 space-y-8 mb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-border/50 pb-4 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Workforce Directory</h1>
          <p className="text-muted-foreground mt-1">Manage your team, roles, and status.</p>
        </div>
        
        <div className="flex items-center gap-4">
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="w-4 h-4 mr-2" /> Add Employee</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Employee</DialogTitle>
                <DialogDescription>Enter the employee's details to add them to the directory.</DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={form.control} name="companyId" render={({ field }) => (
                      <FormItem className="col-span-2">
                        <FormLabel>Company</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select company" /></SelectTrigger></FormControl>
                          <SelectContent>
                            {companies?.map(c => <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="name" render={({ field }) => (
                      <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="email" render={({ field }) => (
                      <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="role" render={({ field }) => (
                      <FormItem><FormLabel>Role/Title</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="department" render={({ field }) => (
                      <FormItem><FormLabel>Department</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="employmentType" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Employment Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl><SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger></FormControl>
                          <SelectContent>
                            <SelectItem value="full-time">Full-time</SelectItem>
                            <SelectItem value="part-time">Part-time</SelectItem>
                            <SelectItem value="contract">Contract</SelectItem>
                            <SelectItem value="intern">Intern</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="startDate" render={({ field }) => (
                      <FormItem><FormLabel>Start Date</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                  <div className="pt-4 flex justify-end">
                    <Button type="submit" disabled={createMutation.isPending}>Add Employee</Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search employees by name, role, or email..." 
            className="pl-9 font-mono text-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={department} onValueChange={setDepartment}>
          <SelectTrigger className="w-full md:w-64 font-mono text-sm">
            <SelectValue placeholder="All Departments" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1,2,3,4].map(i => <div key={i} className="h-48 bg-card border border-border/50 rounded-xl" />)}
        </div>
      ) : filteredEmployees?.length === 0 ? (
        <div className="text-center py-20 bg-card border border-border/50 rounded-xl font-mono text-muted-foreground">
          No employees found.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEmployees?.map(emp => (
            <div key={emp.id} className="bg-card border border-border/50 rounded-xl p-6 shadow-sm hover:border-primary/50 transition-colors flex flex-col">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-secondary/50 flex items-center justify-center text-secondary-foreground font-bold text-lg border border-border/50 shrink-0">
                    {emp.avatar ? <img src={emp.avatar} alt={emp.name} className="w-full h-full object-cover rounded-full" /> : emp.name.substring(0, 1)}
                  </div>
                  <div>
                    <h3 className="font-bold tracking-tight leading-tight">{emp.name}</h3>
                    <div className="text-sm text-primary font-mono truncate max-w-[150px]">{emp.role}</div>
                  </div>
                </div>
                <Badge variant="outline" className={`font-mono text-[10px] uppercase
                  ${emp.status === 'active' ? 'bg-green-500/10 text-green-600 border-green-500/20' : 
                    emp.status === 'on-leave' ? 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20' : 
                    'bg-red-500/10 text-red-600 border-red-500/20'}`}
                >
                  {emp.status.replace('-', ' ')}
                </Badge>
              </div>

              <div className="space-y-2 mb-6 flex-1 text-sm font-mono text-muted-foreground">
                <div className="flex items-center gap-2"><Mail className="w-3.5 h-3.5" /> <span className="truncate">{emp.email}</span></div>
                {emp.phone && <div className="flex items-center gap-2"><Phone className="w-3.5 h-3.5" /> <span>{emp.phone}</span></div>}
                <div className="flex items-center gap-2"><Users className="w-3.5 h-3.5" /> <span>{emp.department} &bull; {emp.employmentType}</span></div>
                <div className="flex items-center gap-2"><Building className="w-3.5 h-3.5" /> <span>{emp.companyName}</span></div>
                <div className="flex items-center gap-2"><Calendar className="w-3.5 h-3.5" /> <span>Started {new Date(emp.startDate).toLocaleDateString()}</span></div>
              </div>

              <div className="flex items-center gap-2 pt-4 border-t border-border/50">
                <Select value={emp.status} onValueChange={(v: EmployeeStatus) => handleUpdateStatus(emp.id, v)}>
                  <SelectTrigger className="flex-1 h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="on-leave">On Leave</SelectItem>
                    <SelectItem value="terminated">Terminated</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="icon" className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0"
                  onClick={() => handleDelete(emp.id)}>
                  <UserMinus className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

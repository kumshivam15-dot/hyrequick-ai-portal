import { useRoute, Link } from "wouter";
import { useGetCompany, useListJobs } from "@workspace/api-client-react";
import { ArrowLeft, MapPin, Globe, Users, Calendar } from "lucide-react";
import { JobCard } from "@/components/shared";

export default function CompanyDetail() {
  const [, params] = useRoute("/companies/:id");
  const companyId = parseInt(params?.id || "0", 10);

  const { data: company, isLoading } = useGetCompany(companyId, { 
    query: { enabled: !!companyId, queryKey: ["company", companyId] } 
  });

  const { data: jobs } = useListJobs({ companyId }, { 
    query: { enabled: !!companyId, queryKey: ["company-jobs", companyId] } 
  });

  if (isLoading) return <div className="p-12 text-center font-mono text-xl animate-pulse">Loading company profile...</div>;
  if (!company) return <div className="p-12 text-center font-mono">Company not found.</div>;

  return (
    <div className="container max-w-screen-xl mx-auto px-4 py-8 mb-20">
      <Link href="/companies" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-2 mb-8 font-mono">
        <ArrowLeft className="w-4 h-4" /> Back to directory
      </Link>

      <div className="bg-card border border-border/50 rounded-2xl p-8 mb-12 flex flex-col md:flex-row gap-8 items-start shadow-sm">
        <div className="w-24 h-24 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-bold text-4xl shrink-0 border border-primary/20">
          {company.logo ? <img src={company.logo} alt={company.name} className="w-full h-full object-cover rounded-xl" /> : company.name.substring(0, 1)}
        </div>
        
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-4xl font-bold tracking-tight">{company.name}</h1>
            <div className="text-lg text-primary font-mono mt-1">{company.industry}</div>
          </div>
          
          <p className="text-muted-foreground max-w-3xl leading-relaxed">
            {company.description}
          </p>

          <div className="flex flex-wrap gap-6 pt-4 border-t border-border/50 text-sm font-mono text-muted-foreground">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4" /> {company.location}
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" /> <span className="capitalize">{company.size}</span>
            </div>
            {company.foundedYear && (
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Est. {company.foundedYear}
              </div>
            )}
            {company.website && (
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" /> 
                <a href={company.website} target="_blank" rel="noreferrer" className="text-primary hover:underline">
                  {company.website.replace(/^https?:\/\//, '')}
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-border/50 pb-4">
          <h2 className="text-2xl font-bold tracking-tight">Open Roles</h2>
          <Badge count={jobs?.length || 0} />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {jobs?.length ? (
            jobs.map(job => <JobCard key={job.id} job={job} />)
          ) : (
            <div className="col-span-2 text-center py-12 bg-secondary/20 rounded-lg text-muted-foreground font-mono">
              No open roles currently listed.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Badge({ count }: { count: number }) {
  return <div className="bg-primary text-primary-foreground font-mono px-3 py-1 rounded-full text-sm font-bold">{count}</div>;
}

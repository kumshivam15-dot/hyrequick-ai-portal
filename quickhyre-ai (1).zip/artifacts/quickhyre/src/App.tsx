import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import { Layout } from "@/components/Layout";
import Home from "@/pages/Home";
import Jobs from "@/pages/Jobs";
import JobDetail from "@/pages/JobDetail";
import Apply from "@/pages/Apply";
import Companies from "@/pages/Companies";
import CompanyDetail from "@/pages/CompanyDetail";
import EmployerDashboard from "@/pages/EmployerDashboard";
import EmployerJobs from "@/pages/EmployerJobs";
import EmployerNewJob from "@/pages/EmployerNewJob";
import EmployerATS from "@/pages/EmployerATS";
import EmployerHRMS from "@/pages/EmployerHRMS";
import CandidateDashboard from "@/pages/CandidateDashboard";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        
        {/* Public / Candidate routes */}
        <Route path="/jobs" component={Jobs} />
        <Route path="/jobs/:id" component={JobDetail} />
        <Route path="/apply/:jobId" component={Apply} />
        <Route path="/companies" component={Companies} />
        <Route path="/companies/:id" component={CompanyDetail} />
        <Route path="/candidate" component={CandidateDashboard} />

        {/* Employer routes */}
        <Route path="/employer" component={EmployerDashboard} />
        <Route path="/employer/jobs" component={EmployerJobs} />
        <Route path="/employer/jobs/new" component={EmployerNewJob} />
        <Route path="/employer/jobs/:id/applicants" component={EmployerATS} />
        <Route path="/employer/hrms" component={EmployerHRMS} />
        
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

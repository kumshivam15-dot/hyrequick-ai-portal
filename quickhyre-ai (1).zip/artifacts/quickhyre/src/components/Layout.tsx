import { Link, useLocation } from "wouter";
import { Briefcase, Building, LayoutDashboard, Search, Users, ChevronDown, UserSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();

  const isEmployer = location.startsWith("/employer");
  const isCandidate = location.startsWith("/candidate");
  const isPublic = !isEmployer && !isCandidate;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 max-w-screen-2xl items-center px-4 md:px-8 justify-between">
          <div className="flex items-center gap-6 md:gap-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-primary text-primary-foreground p-1.5 rounded-md">
                <Briefcase className="h-5 w-5" />
              </div>
              <span className="font-bold text-lg tracking-tight">QuickHyre<span className="text-primary font-mono ml-0.5">.AI</span></span>
            </Link>

            {isPublic && (
              <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
                <Link href="/jobs" className="hover:text-foreground transition-colors">Find Jobs</Link>
                <Link href="/companies" className="hover:text-foreground transition-colors">Companies</Link>
              </nav>
            )}

            {isEmployer && (
              <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
                <Link href="/employer" className={location === "/employer" ? "text-foreground" : "hover:text-foreground"}>Dashboard</Link>
                <Link href="/employer/jobs" className={location.startsWith("/employer/jobs") ? "text-foreground" : "hover:text-foreground"}>Jobs & ATS</Link>
                <Link href="/employer/hrms" className={location.startsWith("/employer/hrms") ? "text-foreground" : "hover:text-foreground"}>HRMS</Link>
              </nav>
            )}

            {isCandidate && (
              <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
                <Link href="/candidate" className="hover:text-foreground transition-colors">My Applications</Link>
                <Link href="/jobs" className="hover:text-foreground transition-colors">Browse Jobs</Link>
              </nav>
            )}
          </div>

          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2 border-border/50 bg-secondary/20">
                  {isEmployer ? (
                    <><Building className="h-4 w-4" /> Employer Mode</>
                  ) : isCandidate ? (
                    <><UserSquare className="h-4 w-4" /> Candidate Mode</>
                  ) : (
                    <><Search className="h-4 w-4" /> Public Mode</>
                  )}
                  <ChevronDown className="h-4 w-4 opacity-50" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>Switch View</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setLocation("/")}>
                  <Search className="mr-2 h-4 w-4" /> Public Jobs
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation("/candidate")}>
                  <UserSquare className="mr-2 h-4 w-4" /> Candidate Portal
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation("/employer")}>
                  <Building className="mr-2 h-4 w-4" /> Employer Suite
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {isPublic && (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="ghost" onClick={() => setLocation("/candidate")}>Sign In</Button>
                <Button onClick={() => setLocation("/employer")}>Post a Job</Button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-border/40 bg-background py-8">
        <div className="container max-w-screen-2xl px-4 md:px-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            <span className="font-semibold">QuickHyre AI</span>
            <span>&copy; {new Date().getFullYear()}</span>
          </div>
          <div className="flex gap-4">
            <Link href="/jobs" className="hover:text-foreground">Jobs</Link>
            <Link href="/companies" className="hover:text-foreground">Companies</Link>
            <Link href="/employer" className="hover:text-foreground">Employers</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

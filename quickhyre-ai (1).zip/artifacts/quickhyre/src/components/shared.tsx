import { Link } from "wouter";
import { Job, Company, ApplicationStatus, JobType } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, MapPin, DollarSign, Clock, Users, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function JobCard({ job }: { job: Job }) {
  return (
    <Card className="hover-elevate transition-all border-border/50 bg-card/50">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-start">
          <div className="space-y-3 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-muted-foreground uppercase">{job.category}</span>
              <Badge variant={job.isActive ? "default" : "secondary"} className="font-mono text-[10px]">
                {job.isActive ? "ACTIVE" : "CLOSED"}
              </Badge>
            </div>
            <Link href={`/jobs/${job.id}`} className="hover:underline">
              <h3 className="text-xl font-bold tracking-tight text-foreground">{job.title}</h3>
            </Link>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Building className="w-4 h-4" />
                <Link href={`/companies/${job.companyId}`} className="hover:text-foreground hover:underline">
                  {job.companyName}
                </Link>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4" />
                {job.location}
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2 text-right">
            {(job.salaryMin || job.salaryMax) && (
              <div className="flex items-center gap-1 font-mono text-sm font-medium text-foreground bg-secondary/50 px-2 py-1 rounded">
                <DollarSign className="w-4 h-4 text-primary" />
                {job.salaryMin ? `${job.salaryMin.toLocaleString()}` : '0'} - {job.salaryMax ? `${job.salaryMax.toLocaleString()}` : '...'}
              </div>
            )}
            <Badge variant="outline" className="font-mono uppercase text-[10px]">{job.type}</Badge>
            <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              <Clock className="w-3 h-3" />
              {new Date(job.postedAt).toLocaleDateString()}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function CompanyCard({ company }: { company: Company }) {
  return (
    <Card className="hover-elevate transition-all border-border/50 h-full flex flex-col">
      <CardContent className="p-6 flex flex-col flex-1">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-primary/10 flex items-center justify-center text-primary font-bold text-xl border border-primary/20">
              {company.logo ? <img src={company.logo} alt={company.name} className="w-full h-full object-cover rounded" /> : company.name.substring(0, 1)}
            </div>
            <div>
              <Link href={`/companies/${company.id}`} className="hover:underline">
                <h3 className="text-lg font-bold tracking-tight">{company.name}</h3>
              </Link>
              <div className="text-sm text-muted-foreground font-mono">{company.industry}</div>
            </div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-3 mb-4 flex-1">{company.description}</p>
        <div className="flex items-center justify-between text-sm mt-auto pt-4 border-t border-border/50">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Users className="w-4 h-4" />
            <span className="capitalize">{company.size}</span>
          </div>
          <div className="font-medium text-primary">
            {company.openJobCount} open roles
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function StatusBadge({ status }: { status: ApplicationStatus }) {
  const styles: Record<ApplicationStatus, string> = {
    pending: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
    reviewed: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    shortlisted: "bg-purple-500/10 text-purple-600 border-purple-500/20",
    interviewed: "bg-indigo-500/10 text-indigo-600 border-indigo-500/20",
    offered: "bg-green-500/10 text-green-600 border-green-500/20",
    hired: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20 bg-emerald-500 text-white",
    rejected: "bg-destructive/10 text-destructive border-destructive/20",
  };

  return (
    <Badge variant="outline" className={`font-mono text-[10px] uppercase ${styles[status]}`}>
      {status}
    </Badge>
  );
}
